INSERT INTO 
	TBL_EMPLOYEES (first_name, last_name, email ) 
VALUES
  	('venkat', 'ramana', 'venkatramana@gmail.com'),
  	('venkat', 'alle', 'xyz@email.com' ),
  	('alle', 'ramana', 'venkatramana@gmail.com'),
  	('prakash', 'alle', 'xyz@email.com'),
  	('sai', 'ramana', 'venkatramana@gmail.com'),
  	('ram', 'alle', 'xyz@email.com');
  	