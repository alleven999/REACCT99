
export default class historyState{
    historyList :[]
    historyState(){
        this.historyList=[];
    }
}