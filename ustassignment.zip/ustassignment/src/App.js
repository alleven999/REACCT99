import {Switch ,Route ,NavLink ,Redirect} from "react-router-dom"
import EmployeeList from "./employee/EmployeeList"
import hireEmp from "./employee/HireEmp"
import history from "./employee/History"
import empInfo from "./employee/EmpInfo"
import './App.css';
import {Navbar ,Nav ,NavDropdown ,Form ,FormControl , Button} from 'react-bootstrap'

function App() {
  return (
    <div className="App">
      <div >
     
      <Navbar bg="light" expand="lg">
      <Navbar.Brand href="/"> Employee Directory</Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
    <Nav className="mr-auto">
      <Nav.Link href="/">Home</Nav.Link>
      <Nav.Link href="/hire">Hire-Employee</Nav.Link>
      <Nav.Link href="/history">History</Nav.Link>
    </Nav>
    </Navbar.Collapse>
    </Navbar>


      </div>
      <Switch>
        <Route path="/" exact  component={EmployeeList}/>
        <Route path="/hire" exact component={hireEmp}/>
        <Route path="/info/:id" exact component={empInfo}/>
        <Route path="/history" exact component={history}/>
        <Redirect path="/"/>
      </Switch>
      <div class="footer">
      </div>
    </div>
  );
}

export default App;
