import axios from "axios";

export const getemployeeList = () => async dispatch => {
  try {
    dispatch({
      type: "EMPLOYEE_LIST_LOADING"
    });

    const res = await axios.get(`http://localhost:8080/employees`)

    dispatch({
      type: "EMPLOYEE_LIST_SUCCESS",
      payload: res.data
    })
  } catch (e) {
    console.log(e);
    dispatch({
      type: "EMPLOYEE_LIST_FAIL",
    })
  }
};

export default getemployeeList;
