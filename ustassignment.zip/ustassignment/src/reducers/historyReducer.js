import historyState from "../state/historyState" 
import {createStore } from "redux";

const initialState = {
   historyList :[]

  };


export function historyReducer(state , action) {
    switch (action.type) {
            case "ADD_EMP_HISTORY":
              return {
                ...state, //spreading the original state
                historyList: [action.payload , ...state.historyList] 

               
              };
              return Object.assign({}, state, {
                results: action.payload,
                fetching: false
              })
            
        default:
            return state
    }
};

// const {createStore} = Redux;
// const store = createStore();
const store = createStore(historyReducer);

export default historyReducer;