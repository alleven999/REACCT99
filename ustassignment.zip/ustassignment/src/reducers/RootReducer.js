import { combineReducers } from "redux"

import {CombineReducers} from "redux";
import {historyReducer} from "./historyReducer";

const RootReducer = combineReducers({
      history:historyReducer
  })

export default RootReducer;
