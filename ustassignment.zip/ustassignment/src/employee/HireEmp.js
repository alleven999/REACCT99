import React , { useState } from "react";
import { useForm } from "react-hook-form";
import axios from "axios";
import {yupResolver} from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useHistory } from "react-router-dom";

const schema =yup.object().shape({
    firstName : yup.string().required(),
    lastName : yup.string().required(),
    email: yup.string().email().required()
});

function HireEmp(){
    let history = useHistory();
    const [state, setState] = useState({
         firstName: "",
         lastName: "",
         email:""
      });
    const { register, handleSubmit ,errors} = useForm({
        resolver:yupResolver(schema) ,
    });
    const onSubmit = data =>{ 
        axios.post(`http://localhost:8080/employees/save` ,state)
        .then(res=>{
          console.log(res);
          history.push('/');
        }).catch(err=>{
          console.log(err);
        })
    
    };
   
    const  changeHandler =(e) =>{
        setState({...state, [e.target.name]: e.target.value})
    }
    return (
      <form onSubmit={handleSubmit(onSubmit)}>
        <h2>Hire Employee </h2>
        <br></br>
        <label><h5>First Name:</h5></label>
        <input name="firstName" value={state.firstName} onChange={changeHandler} ref={register} />
        <p>{errors.firstName?.message}</p>
        <br></br>
        <label><h5>Last Name : </h5></label>
        <input name="lastName" value={state.lastName} onChange={changeHandler}  ref={register} />
        <p>{errors.lastName?.message}</p>
        <br></br>
        <label><h5>Email Id:</h5></label>
        <input name="email" value={state.email} onChange={changeHandler} ref={register} />
        <p>{errors.email?.message}</p>
        <br></br>
        <input type="submit" />
      </form>
    );
  }
export default HireEmp;