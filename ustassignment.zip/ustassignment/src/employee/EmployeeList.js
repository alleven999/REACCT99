import React ,{ useState } from "react";
import { useDispatch, useSelector} from "react-redux";
import _ from "lodash";
import {Link} from "react-router-dom";
import axios from "axios";
import { MDBDataTable } from 'mdbreact';

function EmployeeList(){
    const [list, setEmployeeList] = useState([]);
    React.useEffect(() => {
       axios.get(`http://localhost:8080/employees`)
       .then(res=>{
         console.log(res.data);
         var result = res.data.map(function(el) {
          var o = Object.assign({}, el);
          o.click = <Link to ={"/info/" + o.id}>info</Link>;
          return o;
        })
        console.log(result);
         setEmployeeList(result);
       }).catch(err=>{
         console.log(err);
       })

    }, []);
  
    const data = {
      columns: [
        {
          label: 'id',
          field: 'id',
          sort: 'asc',
          width: 150
        },
        {
          label: 'firstName',
          field: 'firstName',
          sort: 'asc',
          width: 270
        },
        {
          label: 'lastName',
          field: 'lastName',
          sort: 'asc',
          width: 200
        },
        {
          label: 'email',
          field: 'email',
          sort: 'asc',
          width: 200
        },
        {
          label: '',
          field: 'click',
          sort: 'asc',
          width: 200
        }
       
        
      ],
      rows: 
        list             
    };
  
  
    return(
      <div>
           <MDBDataTable
      striped
      bordered
      small
      data={data}
    />

</div>
          
    )
  };
  
  
export default EmployeeList;