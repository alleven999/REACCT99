import React , {useState }from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import logo from '../resources/person-male.png'


function EmpInfo() {
    let params = useParams();
    const [state, setState] = useState("");
    React.useEffect(async() => {
        await axios.get(`http://localhost:8080/employees/${params.id}`)
            .then(res => {
                console.log(res.data);
                let obj = res.data;
                  setState(obj);
                  
            }).catch(err => {
                console.log(err);
            })

    }, [state]);
    console.log("set dispatch.............");
    
    return (
        <div>
            
           <div class="row">
            <div class="col-sm-4"><h2>Associate Info </h2></div>
            <div class="col-sm-5"><img src ={logo} /></div>
            <div class="col-sm-3"><h2> </h2></div>
            </div>
            <div class="row">
            <div class="col-sm"><h5>Emp Id :{state.id}</h5></div>
            <div class="col-sm"><h5></h5></div>
            <div class="col-sm"></div>
            </div>
            <div class="row">
            <div class="col-sm"><h5>First Name : {state.firstName}</h5></div>
            <div class="col-sm"><h5></h5></div>
            <div class="col-sm"></div>
            </div>

            <div class="row">
            <div class="col-sm"><h5>Last Name : {state.lastName}</h5></div>
            <div class="col-sm"></div>
            <div class="col-sm"></div>
            </div>

            <div class="row">
            <div class="col-sm"><h5>Email Id : {state.email}</h5></div>
            <div class="col-sm"></div>
            <div class="col-sm"></div>
            </div>
        </div>
    )
};
export default EmpInfo;