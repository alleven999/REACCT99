import React , {useState }from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import {useDispatch} from "react-redux";
import {store} from "../store"
import logo from '../state/person-male.png'


function EmpInfo() {
    let params = useParams();
    const [state, setState] = useState("");
    var newState =store.getState().history;
    console.log('state changed');
    console.log(newState)
    const dispatch = useDispatch();
    React.useEffect(async() => {
        await axios.get(`http://localhost:8080/employees/${params.id}`)
            .then(res => {
                console.log(res.data);
                let obj = res.data;
                dispatch({
                    type: "ADD_EMP_HISTORY",
                    payload: obj
                  })
                  setState(obj);
                  var newState =store.getState().history;
                  console.log('state changed');
                  console.log(newState)
            }).catch(err => {
                console.log(err);
            })

    }, [dispatch]);
    console.log("set dispatch.............");
    
    return (
        <div>
            
           <div class="row">
            <div class="col-sm-4"><h2>Associate Info </h2></div>
            <div class="col-sm-5"><img src ={logo} /></div>
            <div class="col-sm-3"><h2> </h2></div>
            </div>
            <div class="row">
            <div class="col-sm"><h5>Emp Id :{state.id}</h5></div>
            <div class="col-sm"><h5></h5></div>
            <div class="col-sm"></div>
            </div>
            <div class="row">
            <div class="col-sm"><h5>First Name : {state.firstName}</h5></div>
            <div class="col-sm"><h5></h5></div>
            <div class="col-sm"></div>
            </div>

            <div class="row">
            <div class="col-sm"><h5>Last Name : {state.lastName}</h5></div>
            <div class="col-sm"></div>
            <div class="col-sm"></div>
            </div>

            <div class="row">
            <div class="col-sm"><h5>Email Id : {state.email}</h5></div>
            <div class="col-sm"></div>
            <div class="col-sm"></div>
            </div>
        </div>
    )
};
export default EmpInfo;