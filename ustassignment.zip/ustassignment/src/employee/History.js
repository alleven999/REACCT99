import React from "react";

function EmpInfo() {
    
    return (
        <div>
           search history need to be implemented using Redux.this is in progress
        </div>
    )
};
export default EmpInfo;