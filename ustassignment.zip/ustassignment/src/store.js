import { applyMiddleware } from 'redux';
import {createStore } from "redux";
import {ComposeWithDevTools} from "redux-devtools-extension";
import historyReducer from "./reducers/historyReducer";
import thunkMiddleware from 'redux-thunk';
import { createLogger } from 'redux-logger';

const loggerMiddleware = createLogger();
const initialState = {
    historyList :[]
 
   };
export const store = createStore(
    historyReducer,
    initialState ,
    applyMiddleware(
        thunkMiddleware,
        loggerMiddleware
    )
);

export default store;